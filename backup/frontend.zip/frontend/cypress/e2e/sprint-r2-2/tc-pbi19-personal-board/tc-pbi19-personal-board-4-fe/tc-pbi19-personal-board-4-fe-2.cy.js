describe(`TC-PBI19-PERSIONAL-BOARD-4-FE-2\n 
    Test Scenario : normal
                    - custom status is specific to each board
                    - delete "In Progress" status and transfer "user1 second task" to "Review".`, () => {

    it(`********************************************************
        [1.6] Run this test with your advisor.
            delete "In Progress" status and 
                transfer "user1 second task" to "Review".
        ********************************************************`, () => {
    cy.get('.run.this.test.with.your.advisor').should('exist') ;
    })

})

