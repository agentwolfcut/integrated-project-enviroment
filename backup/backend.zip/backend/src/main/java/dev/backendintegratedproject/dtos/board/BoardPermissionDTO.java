package dev.backendintegratedproject.dtos.board;

import lombok.Data;

@Data
public class BoardPermissionDTO {
    private String permission;
}
