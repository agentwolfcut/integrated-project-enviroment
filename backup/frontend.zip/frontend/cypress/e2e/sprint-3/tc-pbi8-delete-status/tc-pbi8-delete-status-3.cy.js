describe(`TC-PBI8-DELETE-STATUS-3\n 
          Test Scenario : normal - delete status with task(s) \n
           - transfer task(s) to another status.`, () => {
  
    beforeEach(()=> {
        cy.viewport(1024, 768)
        cy.visit('/task') ;
        cy.wait(100) ;
    }) ;
    
    it('Run this test with your advisor.', () => {
    
    })
})