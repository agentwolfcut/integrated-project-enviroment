<script setup></script>

<template>
  <!-- plz edit file in FirstPage.vue -->
  <RouterView />
</template>

<style scoped></style>